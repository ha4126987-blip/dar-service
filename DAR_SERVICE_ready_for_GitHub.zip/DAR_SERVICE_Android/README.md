# DAR SERVICE – Android Studio project

This is an Android WebView app project containing the simplified DAR SERVICE interface.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `DAR_SERVICE_Android` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will create the APK under `app/build/outputs/apk/debug/`.

## Included
- Large service buttons and simple Arabic/Darija-first home screen.
- Read-aloud help button (uses Android/browser speech support).
- French and English interface options.
- WhatsApp click-to-chat integration.
- Basic professional registration demo form.

## Important limitations
- This is an Android Studio source project, not a precompiled APK.
- Real user accounts, SMS verification, shared professional listings, photo uploads, bookings and admin permissions require a secure backend/database.
- WhatsApp opens the installed WhatsApp app (or compatible browser flow); it does not send messages silently.
